import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { OrderserviceService } from 'src/app/services/orderservice.service';

@Component({
  selector: 'app-addorder',
  templateUrl: './addorder.component.html',
  styleUrls: ['./addorder.component.css']
})
export class AddorderComponent implements OnInit {

  orderForm = new FormGroup({
    ramSize: new FormControl(''),
    storageSize: new FormControl(''),
    hours: new FormControl(''),
    osName: new FormControl(''),
    countryCode: new FormControl(''),
  });

  constructor(private orderService: OrderserviceService) { }

  ngOnInit() {
  }
  orderPrice: number = 0;
  priceHasValue: boolean = false;
  onSubmit(){
    this.orderService.setOrder(this.orderForm.value).subscribe(data => {
      this.orderService.getOrderPrice(data.orderId).subscribe(price => {
        this.orderPrice = price
        this.priceHasValue = true;
        this.orderForm = new FormGroup({
          ramSize: new FormControl(''),
          storageSize: new FormControl(''),
          hours: new FormControl(''),
          osName: new FormControl(''),
          countryCode: new FormControl(''),
        });
        this.priceHasValue = false;
      });
    });
  }

}
