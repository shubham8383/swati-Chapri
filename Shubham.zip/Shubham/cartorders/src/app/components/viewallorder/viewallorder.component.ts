import { Component, OnInit } from '@angular/core';
import { Order } from 'src/app/model/order.model';
import { OrderserviceService } from 'src/app/services/orderservice.service';

@Component({
  selector: 'app-viewallorder',
  templateUrl: './viewallorder.component.html',
  styleUrls: ['./viewallorder.component.css']
})
export class ViewallorderComponent implements OnInit {

  constructor(private orderService: OrderserviceService) { }
  orders : Order[];
  orderPrice: number = 0;
  ngOnInit() {
    this.orderService.getAllOrders().subscribe(data => this.orders = data);
  }

  getPrice(id: number){
    this.orderService.getOrderPrice(id).subscribe(data => this.orderPrice = data);
  }
  
}
