import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddorderComponent } from './components/addorder/addorder.component';
import { ViewallorderComponent } from './components/viewallorder/viewallorder.component';


const routes: Routes = [
  {path: '', component: AddorderComponent},
  {path: 'view-all', component: ViewallorderComponent},
  {path: '**', component: AddorderComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
