import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { Order } from '../model/order.model';
@Injectable({
  providedIn: 'root'
})
export class OrderserviceService {
  private baseUrl: string = "http://localhost:8080/order";
  constructor(private http: HttpClient) { }

  setOrder(order: Order){
    return this.http.post<Order>(this.baseUrl, order);
  }

  getAllOrders(){
    return this.http.get<Order[]>(this.baseUrl + '/all');
  }

  getOrderPrice(id: number){
    return this.http.get<number>(this.baseUrl + '/price/' + id);
  }
}
