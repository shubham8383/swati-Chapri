export class Order{
    orderId: number;
    osName: string;
    ramSize: string;
    storageSize: string;
    countryCode: string;
    hours: string;
}