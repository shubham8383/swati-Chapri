package com.order.ecommerce.model;

import javax.persistence.*;

@Entity
@Table(name = "cartorder")
public class Order {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long orderId;

    private String osName;
    private String ramSize;
    private String storageSize;
    private String countryCode;
    private String hours;

    public Long getOrderId() {
        return orderId;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public String getOsName() {
        return osName;
    }

    public void setOsName(String osName) {
        this.osName = osName;
    }

    public String getRamSize() {
        return ramSize;
    }

    public void setRamSize(String ramSize) {
        this.ramSize = ramSize;
    }

    public String getStorageSize() {
        return storageSize;
    }

    public void setStorageSize(String storageSize) {
        this.storageSize = storageSize;
    }

    public String getHours() {
        return hours;
    }

    public void setHours(String hours) {
        this.hours = hours;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public Order(String osName, String ramSize, String storageSize, String countryCode, String hours) {
        this.osName = osName;
        this.ramSize = ramSize;
        this.storageSize = storageSize;
        this.countryCode = countryCode;
        this.hours = hours;
    }

    public Order() {
    }
}
