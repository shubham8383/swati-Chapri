package com.order.ecommerce.service;

import com.order.ecommerce.model.Order;
import com.order.ecommerce.repo.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class OrderServiceImpl implements OrderService {

    @Autowired
    private OrderRepository repository;

    @Override
    public Order getOrder(Long id) {
        return repository.findById(id).get();
    }

    @Override
    public Order setOrder(Order order) {
        return repository.save(order);
    }

    @Override
    public Long getPrice(Long id) {
        // 1GB Ram price 50rs/hr
        // 1GB hdd price 10rs/hr
        // os windows -> 3000rs, linux -> 0
        // countryCode -> us -> 10rs, uk -> 14, ca -> 15
        Order order = repository.findById(id).get();
        Long ram = Long.parseLong(order.getRamSize());
        Long hdd = Long.parseLong(order.getStorageSize());
        String os = order.getOsName();
        Long hrs = Long.parseLong(order.getHours());
        String countryCode = order.getCountryCode();
        Long price = (ram * 50 * hrs) + (hdd * 10 * hrs);
        if(os.equals("windows")){
            price += 3000;
        }
        switch (countryCode){
            case "us":
                price = price * 10;
                break;
            case "uk":
                price = price * 14;
                break;
            default:
                price = price * 15;
                break;
        }
        return price;
    }

    @Override
    public List<Order> getAllOrders() {
        return repository.findAll();
    }
}
