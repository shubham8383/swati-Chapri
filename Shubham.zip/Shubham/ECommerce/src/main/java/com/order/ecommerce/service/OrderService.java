package com.order.ecommerce.service;

import com.order.ecommerce.model.Order;

import java.util.List;
import java.util.Optional;

public interface OrderService {
    public Order getOrder(Long id);
    public Order setOrder(Order order);
    public Long getPrice(Long id);
    public List<Order> getAllOrders();
}
