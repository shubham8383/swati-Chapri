package com.order.ecommerce.controller;

import com.order.ecommerce.model.Order;
import com.order.ecommerce.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/order")
public class OrderController {

    @Autowired
    private OrderService orderService;

    @GetMapping("/{id}")
    public Order getOrder(@PathVariable Long id){
        return orderService.getOrder(id);
    }

    @PostMapping("")
    public Order setOrder(@RequestBody Order order){
        return orderService.setOrder(order);
    }

    @GetMapping("/price/{id}")
    public Long getPrice(@PathVariable Long id){
        return orderService.getPrice(id);
    }

    @GetMapping("/all")
    public List<Order> getAllOrders(){
        return orderService.getAllOrders();
    }
}
